import { Injectable } from '@angular/core';
import { Hero } from './hero';
import { HEROES } from './mock-heroes';
import { Observable, of } from 'rxjs';
//import { MessageService } from '../lib/message.service';

@Injectable({
  providedIn: 'root',
})

export class HeroService {
//  private messageService: MessageService;
  constructor() { }
  
//  getHeroes(): Observable<Hero[]> {
  //  this.messageService.add('HeroService: fetched heroes');
  //  return of(HEROES);
  //}
   
  getHeroes(): Hero[] {
    return HEROES;
  }

}
